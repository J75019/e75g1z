<?php
session_start();
if($_SESSION['authorized'] == "1")
{
}else{
    die('YOU ARE NOT AUTHORIZED');
  }

?>